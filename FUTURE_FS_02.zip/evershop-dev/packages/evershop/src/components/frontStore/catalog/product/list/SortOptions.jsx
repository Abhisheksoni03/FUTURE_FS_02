import { _ } from '../../../../../lib/locale/translate/_.js';

const options = [
  { code: 'price', name: _('Price') },
  { code: 'name', name: _('Name') }
];

export default options;
