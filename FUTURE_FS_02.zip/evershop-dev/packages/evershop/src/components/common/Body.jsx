import Area from '@components/common/Area';
import React from 'react';

export function Body() {
  return (
    <div id="app" className="bg-background">
      <Area id="body" className="wrapper" />
    </div>
  );
}
