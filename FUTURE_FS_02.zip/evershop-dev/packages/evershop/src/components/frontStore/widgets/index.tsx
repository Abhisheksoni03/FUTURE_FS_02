import BasicMenu from './BasicMenu.jsx';
import CollectionProducts from './CollectionProducts.jsx';
import TextBlock from './TextBlock.jsx';

export { CollectionProducts, BasicMenu, TextBlock };
