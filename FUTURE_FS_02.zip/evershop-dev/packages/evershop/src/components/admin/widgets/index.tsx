import BasicMenuSetting from './BasicMenuSetting.jsx';
import CollectionProductsSetting from './CollectionProductsSetting.jsx';
import TextBlockSetting from './TextBlockSetting.jsx';

export { BasicMenuSetting, CollectionProductsSetting, TextBlockSetting };
